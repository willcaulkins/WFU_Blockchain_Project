/*
Group1
Will Caulkins
Caitlin Kelly
Kristen Kovach
 */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Main {
    public static ArrayList<String> stakeholderArr;
    public static ArrayList<String> artefactArr;
    public static ArrayList<Stakeholder> stakeholders;
    public static ArrayList<Artefact> artefacts;
    public static ArrayList<Block> blockchain;

    public static Boolean TreatySC(Transaction t) { // allocates revenue based on the stakes of the owners of the artefact and executes the transaction
        boolean completed = false;
        Artefact artefact = t.getArtefact();
        if ((retrieveProvenance(artefact.getId(),977616000000L).size()>1) || ((retrieveProvenance(artefact.getId()).size()<2))) {
            if (t.getBuyer().getBalance()>=t.getPrice()) {
                t.getAuctionHouse().setBalance(t.getAuctionHouse().getBalance() + (t.getPrice()/10));
                artefact.getLegalOwner().setBalance(artefact.getLegalOwner().getBalance() + (t.getPrice()*artefact.getStakeOfLegalOwner())/100);
                t.getSeller().setBalance(t.getSeller().getBalance() + ((t.getPrice()*(100-artefact.getStakeOfLegalOwner()))/100));
                t.getBuyer().setBalance(t.getBuyer().getBalance() - t.getPrice());
                t.getArtefact().setLegalOwner(t.getBuyer());
                completed = true;
            }
        }
        return completed;
    }

    public static ArrayList<Transaction> retrieveProvenance(String id) { // creates a provenance record for the artefact via all of its prior transactions
        ArrayList<Transaction> provenance = new ArrayList<Transaction>();
        for (Block b : blockchain) {
            String currID = b.getData().getArtefact().getId();
            if (id == currID) {
                provenance.add(b.getData());
            }
        }
        return provenance;
    }

    public static void printProvenance(String id) {
        for (Transaction t : retrieveProvenance(id)) {
            System.out.println(t.toString());
            System.out.println();
        }
    }

    public static ArrayList<Transaction> retrieveProvenance(String id, Long timestamp) { // creates a provenance record for the artefact via all of its prior transactions
        ArrayList<Transaction> provenance = new ArrayList<Transaction>();
        for (Block b : blockchain) {
            String currID = b.getData().getArtefact().getId();
            if ((id == currID) && (b.getData().getTimestamp()>(timestamp))) {
                provenance.add(b.getData());
            }
        }
        return provenance;
    }

    public static boolean verify_Blockchain(ArrayList<Block> BC) { //method to ensure hash functions are working properly (work in progress)
        /*for (int i=1; i<BC.size(); i++) {
            Block b = BC.get(i);
            Block b2 = BC.get(i-1);

            if (b.getCurrentHash().equals(b.calculateBlockHash())) {
                if (b.getPreviousHash().equals(b2.calculateBlockHash())) {
                    if (b.getCurrentHash().startsWith("0000")){
                        return true;
                    } else {
                        System.out.println("1");
                        return false;
                    }
                } else {
                    System.out.println(b.getPreviousHash());
                    System.out.println(b2.calculateBlockHash());
                    System.out.println("2");
                    return false;
                }
            } else {
                System.out.println(b.calculateBlockHash());
                System.out.println(b.getCurrentHash());
                System.out.println("3");
                return false;
            }
        }*/
        return true;
    }

    public static void main(String[] args) throws ParseException {
        blockchain = new ArrayList<Block>();
        int prefix = 4;   //we want our hash to start with four zeroes
        String prefixString = new String(new char[prefix]).replace('\0', '0');

        stakeholders = new ArrayList<Stakeholder>();
        artefacts = new ArrayList<Artefact>();

        Stakeholder buyer1 = new Stakeholder("001", "Kristen Kovach", "Kristen's Address", 10000.00);
        Stakeholder seller1 = new Stakeholder("002", "Caitlin Kelly", "Caitlin's Address", 10000.00);
        Stakeholder Mexico = new Stakeholder("003", "Mexico", "1234 Mexico City Lane", 10000.00);
        Artefact artefact1 = new Artefact("1001", "Western Mexican Effigy Bowl", Mexico, seller1);
        Stakeholder auctionHouse = new Stakeholder("004", "Sotheby's", "Sotheby's Address", 10000.00);
        Transaction data1 = new Transaction(artefact1, new Date().getTime(), seller1, buyer1, auctionHouse, 1000);

        stakeholders.add(buyer1);
        stakeholders.add(seller1);
        stakeholders.add(Mexico);
        stakeholders.add(auctionHouse);
        artefacts.add(artefact1);

        Stakeholder buyer2 = new Stakeholder("005", "Will Caulkins", "Will's Address", 10000.00);
        Stakeholder seller2 = new Stakeholder("006", "Sarra Alqahtani", "Sarra's Address" , 10000.00);
        Stakeholder Canada = new Stakeholder("007", "Canada", "1600 Vancouver Ave", 10000.00);
        Artefact artefact2 = new Artefact("1002", "Hockey Stick", Canada, seller2);
        Transaction data2 = new Transaction(artefact2, new Date().getTime(), seller2, buyer2, auctionHouse, 1000);

        stakeholders.add(buyer2);
        stakeholders.add(seller2);
        stakeholders.add(Canada);
        artefacts.add(artefact2);

        Stakeholder buyer3 = new Stakeholder("008", "Hercules", "Hercules's Address", 10000.00);
        Stakeholder seller3 = new Stakeholder("009", "Zeus", "Mount Olympus" , 10000.00);
        Stakeholder Greece = new Stakeholder("0010", "Greece", "1600 Athens Ave", 10000.00);
        Artefact artefact3 = new Artefact("1003", "Parthenon", Greece, seller3);
        Transaction data3 = new Transaction(artefact3, new Date().getTime(), seller3, buyer3, auctionHouse, 1000);

        stakeholders.add(buyer3);
        stakeholders.add(seller3);
        stakeholders.add(Greece);
        artefacts.add(artefact3);

        stakeholderArr = new ArrayList<String>();
        int i=0;
        for (Stakeholder s : stakeholders) {
            stakeholderArr.add(s.getName());
            i++;
        }
        artefactArr = new ArrayList<String>();
        i=0;
        for (Artefact a : artefacts) {
            artefactArr.add(a.getName());
            i++;
        }

        Block genesisBlock = new Block(data1, "00001", new Date().getTime());
        genesisBlock.mineBlock(prefix);
        if (genesisBlock.getCurrentHash().substring(0, prefix).equals(prefixString)) {
            blockchain.add(genesisBlock);
        } else {
            System.out.println("Malicious block, not added to the chain");
            gui.messages.setText("Malicious block, not added to the chain");
        }

        Block secondBlock = new Block(data2, blockchain.get(blockchain.size() - 1).getCurrentHash(), new Date().getTime());
        secondBlock.mineBlock(prefix);
        if (secondBlock.getCurrentHash().substring(0, prefix).equals(prefixString) &&  verify_Blockchain(blockchain)) {
            blockchain.add(secondBlock);
        } else {
            System.out.println("Malicious block, not added to the chain");
            gui.messages.setText("Malicious block, not added to the chain");
        }

        Block newBlock = new Block(data3, blockchain.get(blockchain.size() - 1).getCurrentHash(), new Date().getTime());
        newBlock.mineBlock(prefix);
        if (newBlock.getCurrentHash().substring(0, prefix).equals(prefixString) &&  verify_Blockchain(blockchain)) {
            blockchain.add(newBlock);
        } else {
            System.out.println("Malicious block, not added to the chain");
            gui.messages.setText("Malicious block, not added to the chain");
        }

        gui.main(args);
    }
}
